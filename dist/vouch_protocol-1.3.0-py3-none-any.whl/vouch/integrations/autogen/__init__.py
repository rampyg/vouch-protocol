"""Vouch AutoGen integration."""
from .tool import sign_action, VOUCH_FUNCTIONS

__all__ = ["sign_action", "VOUCH_FUNCTIONS"]
